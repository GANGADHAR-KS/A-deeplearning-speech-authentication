from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
import base64
import os
import json
from .models.cnn_model import VisualSpeechCNN
from .models.face_model import FaceDetector, FaceRecognizer
from .utils.preprocessing import preprocess_video_frames

app = Flask(__name__, static_folder='../frontend')
CORS(app)

# Initialize models
face_detector = FaceDetector()
face_recognizer = FaceRecognizer()
speech_cnn = VisualSpeechCNN()

# Load or create user database
USER_DB_PATH = 'users.json'
if os.path.exists(USER_DB_PATH):
    with open(USER_DB_PATH, 'r') as f:
        users = json.load(f)
else:
    users = {}

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    face_data = data.get('faceData')  # Base64 encoded image
    speech_data = data.get('speechData')  # Base64 encoded video frames
    
    # Decode and process face image
    face_img = base64.b64decode(face_data.split(',')[1])
    nparr = np.frombuffer(face_img, np.uint8)
    face_img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    # Detect face
    face = face_detector.detect(face_img)
    if not face:
        return jsonify({'success': False, 'message': 'No face detected'})
    
    # Extract face features
    face_features = face_recognizer.extract_features(face)
    
    # Process speech video frames
    video_frames = []
    for frame in speech_data:
        img_data = base64.b64decode(frame.split(',')[1])
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        video_frames.append(img)
    
    # Preprocess video frames to extract lip movements
    lip_frames = preprocess_video_frames(video_frames)
    
    # Extract speech features using CNN
    speech_features = speech_cnn.extract_features(lip_frames)
    
    # Store user data
    users[username] = {
        'face_features': face_features.tolist(),
        'speech_features': speech_features.tolist()
    }
    
    # Save updated user database
    with open(USER_DB_PATH, 'w') as f:
        json.dump(users, f)
    
    return jsonify({'success': True, 'message': 'User registered successfully'})

@app.route('/api/authenticate', methods=['POST'])
def authenticate():
    data = request.get_json()
    username = data.get('username')
    face_data = data.get('faceData')
    speech_data = data.get('speechData')
    
    # Check if user exists
    if username not in users:
        return jsonify({'success': False, 'message': 'User not found'})
    
    # Decode and process face image
    face_img = base64.b64decode(face_data.split(',')[1])
    nparr = np.frombuffer(face_img, np.uint8)
    face_img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    # Detect face
    face = face_detector.detect(face_img)
    if not face:
        return jsonify({'success': False, 'message': 'No face detected'})
    
    # Extract face features
    face_features = face_recognizer.extract_features(face)
    
    # Compare face features
    stored_face_features = np.array(users[username]['face_features'])
    face_similarity = face_recognizer.compare_features(face_features, stored_face_features)
    
    # Process speech video frames
    video_frames = []
    for frame in speech_data:
        img_data = base64.b64decode(frame.split(',')[1])
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        video_frames.append(img)
    
    # Preprocess video frames to extract lip movements
    lip_frames = preprocess_video_frames(video_frames)
    
    # Extract speech features using CNN
    speech_features = speech_cnn.extract_features(lip_frames)
    
    # Compare speech features
    stored_speech_features = np.array(users[username]['speech_features'])
    speech_similarity = speech_cnn.compare_features(speech_features, stored_speech_features)
    
    # Calculate combined similarity score (70% face, 30% speech)
    combined_score = 0.7 * face_similarity + 0.3 * speech_similarity
    
    # Authentication threshold
    if combined_score > 0.85:
        return jsonify({'success': True, 'message': 'Authentication successful'})
    else:
        return jsonify({'success': False, 'message': 'Authentication failed'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)