import cv2
import numpy as np
import dlib

def preprocess_video_frames(frames):
    """Preprocess video frames to extract lip movements"""
    # Initialize face detector and landmark predictor
    detector = dlib.get_frontal_face_detector()
    predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
    
    lip_frames = []
    
    for frame in frames:
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = detector(gray)
        
        if len(faces) == 0:
            continue
        
        # Use the first face detected
        face = faces[0]
        
        # Get facial landmarks
        landmarks = predictor(gray, face)
        
        # Extract mouth region (landmarks 48-68)
        mouth_points = []
        for i in range(48, 68):
            x = landmarks.part(i).x
            y = landmarks.part(i).y
            mouth_points.append((x, y))
        
        mouth_points = np.array(mouth_points)
        
        # Get bounding box
        x, y = np.min(mouth_points, axis=0)
        w, h = np.max(mouth_points, axis=0) - np.min(mouth_points, axis=0)
        
        # Add margin
        margin = 10
        x = max(0, x - margin)
        y = max(0, y - margin)
        w = w + 2 * margin
        h = h + 2 * margin
        
        # Ensure we don't go out of bounds
        img_h, img_w = gray.shape
        x_end = min(x + w, img_w)
        y_end = min(y + h, img_h)
        
        # Extract mouth region
        mouth_region = gray[y:y_end, x:x_end]
        
        # Resize to standard size (64x64)
        mouth_region = cv2.resize(mouth_region, (64, 64))
        
        # Normalize
        mouth_region = mouth_region / 255.0
        
        # Reshape to include channel dimension
        mouth_region = np.expand_dims(mouth_region, axis=-1)
        
        lip_frames.append(mouth_region)
    
    # Ensure we have at least one frame
    if len(lip_frames) == 0:
        # Create a blank frame
        lip_frames.append(np.zeros((64, 64, 1)))
    
    return lip_frames

def normalize_image(image):
    """Normalize image pixel values to range [0, 1]"""
    return image / 255.0

def detect_face(image):
    """Detect face in image and return face region"""
    # Initialize face detector
    detector = dlib.get_frontal_face_detector()
    
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Detect faces
    faces = detector(gray)
    
    if len(faces) == 0:
        return None
    
    # Use the first face found
    face = faces[0]
    
    # Get face region
    x, y, w, h = face.left(), face.top(), face.width(), face.height()
    face_region = image[y:y+h, x:x+w]
    
    # Resize to standard size
    face_region = cv2.resize(face_region, (128, 128))
    
    return face_region

def align_face(image, landmarks):
    """Align face based on eye positions"""
    # Extract eye landmarks
    left_eye = landmarks[36:42]
    right_eye = landmarks[42:48]
    
    # Calculate eye centers
    left_eye_center = np.mean(left_eye, axis=0).astype(int)
    right_eye_center = np.mean(right_eye, axis=0).astype(int)
    
    # Calculate angle
    dy = right_eye_center[1] - left_eye_center[1]
    dx = right_eye_center[0] - left_eye_center[0]
    angle = np.degrees(np.arctan2(dy, dx))
    
    # Get rotation matrix
    rows, cols = image.shape[:2]
    rotation_matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle, 1)
    
    # Apply rotation
    aligned_face = cv2.warpAffine(image, rotation_matrix, (cols, rows))
    
    return aligned_face