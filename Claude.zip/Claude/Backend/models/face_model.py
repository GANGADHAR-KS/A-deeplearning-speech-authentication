import cv2
import numpy as np
import dlib

class FaceDetector:
    def __init__(self):
        # Initialize dlib's face detector
        self.detector = dlib.get_frontal_face_detector()
        
        # Load facial landmark predictor
        self.predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
        
    def detect(self, image):
        """Detect a face in an image and return the face region"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = self.detector(gray)
        
        if len(faces) == 0:
            return None
        
        # Use the first face found
        face = faces[0]
        
        # Get face region
        x, y, w, h = face.left(), face.top(), face.width(), face.height()
        face_region = image[y:y+h, x:x+w]
        
        return face_region
    
    def detect_landmarks(self, image):
        """Detect facial landmarks in an image"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = self.detector(gray)
        
        if len(faces) == 0:
            return None
        
        # Use the first face found
        face = faces[0]
        
        # Get landmarks
        landmarks = self.predictor(gray, face)
        
        # Convert landmarks to numpy array
        landmarks_points = []
        for i in range(68):
            x = landmarks.part(i).x
            y = landmarks.part(i).y
            landmarks_points.append((x, y))
        
        return np.array(landmarks_points)
    
    def extract_mouth_region(self, image, landmarks):
        """Extract the mouth region from an image using landmarks"""
        # Mouth landmarks indices (49-68)
        mouth_points = landmarks[48:68]
        
        # Get bounding box
        x, y = np.min(mouth_points, axis=0)
        w, h = np.max(mouth_points, axis=0) - np.min(mouth_points, axis=0)
        
        # Add some margin
        margin = 10
        x = max(0, x - margin)
        y = max(0, y - margin)
        w = w + 2 * margin
        h = h + 2 * margin
        
        # Ensure we don't go out of bounds
        h, w_max, _ = image.shape
        x_end = min(x + w, w_max)
        y_end = min(y + h, h)
        
        # Extract mouth region
        mouth_region = image[y:y_end, x:x_end]
        
        return mouth_region


class FaceRecognizer:
    def __init__(self):
        # Initialize face recognition model
        self.face_encoder = dlib.face_recognition_model_v1("dlib_face_recognition_resnet_model_v1.dat")
        
        # Initialize face detector
        self.detector = dlib.get_frontal_face_detector()
        
        # Load facial landmark predictor
        self.predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
        
    def extract_features(self, face_image):
        """Extract features from a face image"""
        # Convert to dlib format
        if face_image is None:
            return np.zeros(128)
            
        # Convert to grayscale
        gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
        
        # Detect face (should be only one since we're already working with a face region)
        faces = self.detector(gray)
        
        if len(faces) == 0:
            # Return zeros if no face found
            return np.zeros(128)
        
        # Use the first face found
        face = faces[0]
        
        # Get landmarks
        landmarks = self.predictor(gray, face)
        
        # Get face encoding
        face_encoding = self.face_encoder.compute_face_descriptor(face_image, landmarks)
        
        return np.array(face_encoding)
    
    def compare_features(self, features1, features2):
        """Compare two feature vectors and return similarity score"""
        # Calculate Euclidean distance
        distance = np.linalg.norm(features1 - features2)
        
        # Convert to similarity (0 to 1)
        similarity = 1.0 / (1.0 + distance)
        
        return similarity