import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models

class VisualSpeechCNN:
    def __init__(self):
        self.model = self._build_model()
        
    def _build_model(self):
        """Build CNN model for visual speech recognition"""
        model = models.Sequential()
        
        # Input shape: (frames, height, width, channels)
        model.add(layers.Conv3D(32, (3, 3, 3), activation='relu', 
                             input_shape=(15, 64, 64, 1)))
        model.add(layers.MaxPooling3D((1, 2, 2)))
        model.add(layers.Conv3D(64, (3, 3, 3), activation='relu'))
        model.add(layers.MaxPooling3D((1, 2, 2)))
        model.add(layers.Conv3D(128, (3, 3, 3), activation='relu'))
        model.add(layers.MaxPooling3D((1, 2, 2)))
        model.add(layers.Flatten())
        model.add(layers.Dense(128, activation='relu'))
        model.add(layers.Dropout(0.5))
        model.add(layers.Dense(64, activation='relu'))
        
        # Create feature extraction model
        feature_model = models.Model(inputs=model.input, 
                                   outputs=model.layers[-2].output)
        
        return feature_model
    
    def extract_features(self, lip_frames):
        """Extract speech features from lip movement frames"""
        # Preprocess frames
        processed_frames = self._preprocess_frames(lip_frames)
        
        # Extract features
        features = self.model.predict(np.expand_dims(processed_frames, axis=0))[0]
        return features
    
    def _preprocess_frames(self, lip_frames):
        """Preprocess lip movement frames for CNN input"""
        # Ensure we have exactly 15 frames (pad or truncate)
        if len(lip_frames) < 15:
            # Pad frames by duplicating last frame
            padding = [lip_frames[-1]] * (15 - len(lip_frames))
            lip_frames = lip_frames + padding
        elif len(lip_frames) > 15:
            # Select evenly spaced frames
            indices = np.linspace(0, len(lip_frames) - 1, 15, dtype=int)
            lip_frames = [lip_frames[i] for i in indices]
        
        # Resize to 64x64 and convert to grayscale
        processed_frames = []
        for frame in lip_frames:
            if frame.shape[0] != 64 or frame.shape[1] != 64:
                frame = tf.image.resize(frame, (64, 64)).numpy()
            
            # Convert to grayscale if not already
            if frame.shape[-1] == 3:
                frame = np.mean(frame, axis=-1, keepdims=True)
            
            processed_frames.append(frame)
        
        # Stack frames
        processed_frames = np.array(processed_frames)
        
        return processed_frames
    
    def compare_features(self, features1, features2):
        """Compare two feature vectors and return similarity score"""
        # Calculate cosine similarity
        dot_product = np.dot(features1, features2)
        norm1 = np.linalg.norm(features1)
        norm2 = np.linalg.norm(features2)
        similarity = dot_product / (norm1 * norm2)
        
        return similarity
    
    def train(self, X, y):
        """Train the model with lip movement videos and authentication labels"""
        # Convert the feature extraction model to a classification model
        input_layer = self.model.input
        output_layer = layers.Dense(1, activation='sigmoid')(self.model.output)
        classification_model = models.Model(inputs=input_layer, outputs=output_layer)
        
        # Compile the model
        classification_model.compile(optimizer='adam',
                                   loss='binary_crossentropy',
                                   metrics=['accuracy'])
        
        # Train the model
        classification_model.fit(X, y, epochs=10, batch_size=32, validation_split=0.2)
        
        # Update the feature extraction model
        for i, layer in enumerate(classification_model.layers[:-1]):
            self.model.layers[i].set_weights(layer.get_weights())