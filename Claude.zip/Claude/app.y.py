import os
import cv2
import numpy as np
import tensorflow as tf
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import datetime
import uuid
import json
from werkzeug.utils import secure_filename

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configuration
UPLOAD_FOLDER = 'uploads'
DATABASE_FILE = 'database.json'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4', 'webm'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize database file if it doesn't exist
if not os.path.exists(DATABASE_FILE):
    with open(DATABASE_FILE, 'w') as f:
        json.dump({'users': []}, f)

# Load face and speech recognition models
def load_models():
    # Load the face recognition model
    face_model = tf.keras.models.load_model('models/face_recognition_model.h5', compile=False)
    
    # Load the visual speech recognition model
    speech_model = tf.keras.models.load_model('models/visual_speech_model.h5', compile=False)
    
    return face_model, speech_model

# Try to load models, but handle the case where they don't exist yet
try:
    face_model, speech_model = load_models()
    models_loaded = True
except:
    print("Models not found. They will be created during training.")
    models_loaded = False

def allowed_file(filename):
    return '.' in filename and filename.split('.')[-1].lower() in ALLOWED_EXTENSIONS

# Preprocessing functions
def preprocess_face_image(image_path):
    """Preprocess an image for face recognition"""
    img = cv2.imread(image_path)
    if img is None:
        return None
    
    # Convert to RGB (OpenCV uses BGR)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Face detection
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    
    if len(faces) == 0:
        return None
    
    # Process the largest face
    x, y, w, h = max(faces, key=lambda rect: rect[2] * rect[3])
    face = img[y:y+h, x:x+w]
    
    # Resize for model input
    face = cv2.resize(face, (160, 160))
    
    # Normalize pixel values
    face = face.astype(np.float32) / 255.0
    
    return np.expand_dims(face, axis=0)

def extract_mouth_frames(video_path, num_frames=20):
    """Extract mouth regions from video frames for lip reading"""
    cap = cv2.VideoCapture(video_path)
    frames = []
    
    # Face detector
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    
    frame_count = 0
    while frame_count < num_frames:
        ret, frame = cap.read()
        if not ret:
            break
            
        # Convert to grayscale for faster processing
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        if len(faces) == 0:
            continue
            
        # Extract the largest face
        x, y, w, h = max(faces, key=lambda rect: rect[2] * rect[3])
        
        # Define mouth ROI (region of interest)
        # This is an approximation, would be better with a dedicated mouth detector
        mouth_y = y + int(h * 0.7)  # Lower part of the face
        mouth_h = int(h * 0.3)      # About 30% of face height
        mouth = frame[mouth_y:mouth_y+mouth_h, x:x+w]
        
        # Resize mouth region
        mouth = cv2.resize(mouth, (100, 50))
        
        # Normalize
        mouth = mouth.astype(np.float32) / 255.0
        
        frames.append(mouth)
        frame_count += 1
    
    cap.release()
    
    # Pad or truncate to ensure consistent frame count
    if len(frames) == 0:
        return None
    
    if len(frames) < num_frames:
        # Pad by duplicating the last frame
        last_frame = frames[-1]
        frames.extend([last_frame] * (num_frames - len(frames)))
    elif len(frames) > num_frames:
        # Truncate
        frames = frames[:num_frames]
    
    return np.array(frames)

# Training functions
def create_face_model():
    """Create a CNN model for face recognition"""
    base_model = tf.keras.applications.MobileNetV2(
        input_shape=(160, 160, 3),
        include_top=False,
        weights='imagenet'
    )
    
    # Freeze the base model
    base_model.trainable = False
    
    model = tf.keras.Sequential([
        base_model,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dense(512, activation='relu'),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dense(64)  # Embedding size
    ])
    
    return model

def create_speech_model(num_frames=20):
    """Create a CNN model for visual speech recognition"""
    model = tf.keras.Sequential([
        tf.keras.layers.Conv3D(32, (3, 3, 3), activation='relu', input_shape=(num_frames, 50, 100, 3)),
        tf.keras.layers.MaxPooling3D((1, 2, 2)),
        tf.keras.layers.Conv3D(64, (3, 3, 3), activation='relu'),
        tf.keras.layers.MaxPooling3D((1, 2, 2)),
        tf.keras.layers.Conv3D(128, (3, 3, 3), activation='relu'),
        tf.keras.layers.MaxPooling3D((1, 2, 2)),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(128)  # Embedding size
    ])
    
    return model

def train_face_model(face_images, user_ids):
    """Train or update the face recognition model"""
    global face_model, models_loaded
    
    if not models_loaded:
        face_model = create_face_model()
    
    # For a real implementation, you would use a triplet loss or similar approach
    # Here we're simplifying by just updating the embeddings dictionary
    
    # Create embeddings for each face
    embeddings = {}
    for img, user_id in zip(face_images, user_ids):
        embedding = face_model.predict(img)
        embeddings[user_id] = embedding.flatten()
    
    # Save embeddings to disk
    os.makedirs('models', exist_ok=True)
    np.save('models/face_embeddings.npy', embeddings)
    
    # Save model
    face_model.save('models/face_recognition_model.h5')
    
    return embeddings

def train_speech_model(speech_videos, passcodes, user_ids):
    """Train or update the visual speech recognition model"""
    global speech_model, models_loaded
    
    if not models_loaded:
        speech_model = create_speech_model()
    
    # Similar to face model, in a real implementation we'd use proper training
    # Here we're just saving the embeddings
    
    # Create embeddings for each speech video
    embeddings = {}
    passcode_map = {}
    
    for video, passcode, user_id in zip(speech_videos, passcodes, user_ids):
        embedding = speech_model.predict(np.expand_dims(video, axis=0))
        embeddings[user_id] = embedding.flatten()
        passcode_map[user_id] = passcode
    
    # Save embeddings and passcode map to disk
    os.makedirs('models', exist_ok=True)
    np.save('models/speech_embeddings.npy', embeddings)
    
    with open('models/passcode_map.json', 'w') as f:
        json.dump(passcode_map, f)
    
    # Save model
    speech_model.save('models/visual_speech_model.h5')
    
    return embeddings, passcode_map

# API routes
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/register', methods=['POST'])
def register():
    if 'face' not in request.files or 'speech' not in request.files:
        return jsonify({'error': 'Missing face or speech files'}), 400
    
    face_file = request.files['face']
    speech_file = request.files['speech']
    username = request.form.get('username')
    passcode = request.form.get('passcode')
    
    if not username or not passcode:
        return jsonify({'error': 'Missing username or passcode'}), 400
    
    if face_file.filename == '' or speech_file.filename == '':
        return jsonify({'error': 'No selected files'}), 400
        
    if not allowed_file(face_file.filename) or not allowed_file(speech_file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    
    # Load existing users
    with open(DATABASE_FILE, 'r') as f:
        database = json.load(f)
    
    # Check if username already exists
    if any(user['username'] == username for user in database['users']):
        return jsonify({'error': 'Username already exists'}), 400
    
    # Save files
    user_id = str(uuid.uuid4())
    face_filename = secure_filename(f"{user_id}_face.jpg")
    speech_filename = secure_filename(f"{user_id}_speech.mp4")
    
    face_path = os.path.join(app.config['UPLOAD_FOLDER'], face_filename)
    speech_path = os.path.join(app.config['UPLOAD_FOLDER'], speech_filename)
    
    face_file.save(face_path)
    speech_file.save(speech_path)
    
    # Preprocess images
    face_data = preprocess_face_image(face_path)
    speech_data = extract_mouth_frames(speech_path)
    
    if face_data is None:
        os.remove(face_path)
        os.remove(speech_path)
        return jsonify({'error': 'No face detected in image'}), 400
    
    if speech_data is None:
        os.remove(face_path)
        os.remove(speech_path)
        return jsonify({'error': 'Could not process speech video'}), 400
    
    # Train models
    train_face_model([face_data], [user_id])
    train_speech_model([speech_data], [passcode], [user_id])
    
    # Add user to database
    database['users'].append({
        'id': user_id,
        'username': username,
        'face_file': face_filename,
        'speech_file': speech_filename,
        'created_at': datetime.datetime.now().isoformat()
    })
    
    with open(DATABASE_FILE, 'w') as f:
        json.dump(database, f)
    
    return jsonify({'success': True, 'message': 'User registered successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    if 'face' not in request.files or 'speech' not in request.files:
        return jsonify({'error': 'Missing face or speech files'}), 400
    
    face_file = request.files['face']
    speech_file = request.files['speech']
    username = request.form.get('username')
    
    if not username:
        return jsonify({'error': 'Missing username'}), 400
    
    if face_file.filename == '' or speech_file.filename == '':
        return jsonify({'error': 'No selected files'}), 400
        
    if not allowed_file(face_file.filename) or not allowed_file(speech_file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    
    # Load existing users
    with open(DATABASE_FILE, 'r') as f:
        database = json.load(f)
    
    # Find user by username
    user = next((user for user in database['users'] if user['username'] == username), None)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Save temporary files
    temp_face_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_face.jpg')
    temp_speech_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_speech.mp4')
    
    face_file.save(temp_face_path)
    speech_file.save(temp_speech_path)
    
    # Preprocess images
    face_data = preprocess_face_image(temp_face_path)
    speech_data = extract_mouth_frames(temp_speech_path)
    
    if face_data is None:
        return jsonify({'error': 'No face detected in image'}), 400
    
    if speech_data is None:
        return jsonify({'error': 'Could not process speech video'}), 400
    
    # Load models if they exist
    try:
        face_model, speech_model = load_models()
        models_loaded = True
        
        # Load embeddings
        face_embeddings = np.load('models/face_embeddings.npy', allow_pickle=True).item()
        speech_embeddings = np.load('models/speech_embeddings.npy', allow_pickle=True).item()
        
        with open('models/passcode_map.json', 'r') as f:
            passcode_map = json.load(f)
    except:
        return jsonify({'error': 'Authentication system not initialized'}), 500
    
    # Verify face
    user_id = user['id']
    if user_id not in face_embeddings:
        return jsonify({'error': 'User face data not found'}), 404
    
    user_face_embedding = face_embeddings[user_id]
    input_face_embedding = face_model.predict(face_data).flatten()
    
    # Calculate face similarity (cosine similarity)
    face_similarity = np.dot(user_face_embedding, input_face_embedding) / (
        np.linalg.norm(user_face_embedding) * np.linalg.norm(input_face_embedding)
    )
    
    # Verify speech
    if user_id not in speech_embeddings:
        return jsonify({'error': 'User speech data not found'}), 404
    
    user_speech_embedding = speech_embeddings[user_id]
    input_speech_embedding = speech_model.predict(np.expand_dims(speech_data, axis=0)).flatten()
    
    # Calculate speech similarity (cosine similarity)
    speech_similarity = np.dot(user_speech_embedding, input_speech_embedding) / (
        np.linalg.norm(user_speech_embedding) * np.linalg.norm(input_speech_embedding)
    )
    
    # Clean up temporary files
    os.remove(temp_face_path)
    os.remove(temp_speech_path)
    
    # Authentication decision
    face_threshold = 0.85  # These thresholds would need tuning
    speech_threshold = 0.80
    
    if face_similarity >= face_threshold and speech_similarity >= speech_threshold:
        return jsonify({
            'success': True,
            'message': 'Authentication successful',
            'face_confidence': float(face_similarity),
            'speech_confidence': float(speech_similarity)
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Authentication failed',
            'face_confidence': float(face_similarity),
            'speech_confidence': float(speech_similarity)
        })

@app.route('/api/users', methods=['GET'])
def get_users():
    with open(DATABASE_FILE, 'r') as f:
        database = json.load(f)
    
    # Return only non-sensitive information
    users = [{'username': user['username'], 'id': user['id'], 'created_at': user['created_at']} 
             for user in database['users']]
    
    return jsonify({'users': users})

if __name__ == '__main__':
    app.run(debug=True, port=5000)