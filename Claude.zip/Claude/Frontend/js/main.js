// DOM Elements
const loginTab = document.getElementById('login-tab');
const registerTab = document.getElementById('register-tab');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

const loginVideo = document.getElementById('login-video');
const loginCanvas = document.getElementById('login-canvas');
const loginCaptureBtn = document.getElementById('login-capture-btn');
const loginRecordBtn = document.getElementById('login-record-btn');
const loginSubmitBtn = document.getElementById('login-submit-btn');
const loginUsername = document.getElementById('login-username');
const loginMessage = document.getElementById('login-message');
const loginSpeechIndicator = document.getElementById('login-speech-indicator');
const loginCountdown = document.getElementById('login-countdown');

const registerVideo = document.getElementById('register-video');
const registerCanvas = document.getElementById('register-canvas');
const registerCaptureBtn = document.getElementById('register-capture-btn');
const registerRecordBtn = document.getElementById('register-record-btn');
const registerSubmitBtn = document.getElementById('register-submit-btn');
const registerUsername = document.getElementById('register-username');
const registerMessage = document.getElementById('register-message');
const registerSpeechIndicator = document.getElementById('register-speech-indicator');
const registerCountdown = document.getElementById('register-countdown');

// Application state
const state = {
    login: {
        faceData: null,
        speechData: [],
        faceCaptured: false,
        speechRecorded: false
    },
    register: {
        faceData: null,
        speechData: [],
        faceCaptured: false,
        speechRecorded: false
    },
    mediaStream: null,
    recordingInterval: null
};

// Tab switching
loginTab.addEventListener('click', () => {
    loginTab.classList.add('active');
    registerTab.classList.remove('active');
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
});

registerTab.addEventListener('click', () => {
    registerTab.classList.add('active');
    loginTab.classList.remove('active');
    registerForm.style.display = 'block';
    loginForm.style.display = 'none';
});

// Initialize webcam
async function initWebcam(videoElement) {
    try {
        state.mediaStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'user' },
            audio: false
        });
        videoElement.srcObject = state.mediaStream;
        return true;
    } catch (error) {
        console.error('Error accessing webcam:', error);
        return false;
    }
}

// Capture face image
function captureFace(video, canvas, type) {
    const context = canvas.getContext('2d');
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Get image data as base64
    const imageData = canvas.toDataURL('image/jpeg');
    
    // Store in state
    state[type].faceData = imageData;
    state[type].faceCaptured = true;
    
    // Update UI
    updateSubmitButtonState(type);
    showMessage(`Face image captured!`, type, 'success');
}

// Record speech
function recordSpeech(type) {
    const speechIndicator = document.getElementById(`${type}-speech-indicator`);
    const countdownEl = document.getElementById(`${type}-countdown`);
    const recordBtn = document.getElementById(`${type}-record-btn`);
    
    // Clear previous recordings
    state[type].speechData = [];
    state[type].speechRecorded = false;
    
    // Update UI
    speechIndicator.querySelector('.circle').classList.add('recording');
    speechIndicator.querySelector('span').textContent = 'Recording...';
    recordBtn.disabled = true;
    
    // Start countdown
    let countdown = 3;
    countdownEl.textContent = countdown;
    
    // Start recording frames
    const videoElement = document.getElementById(`${type}-video`);
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    
    // Record frames at 10fps
    const recordingFrames = [];
    state.recordingInterval = setInterval(() => {
        // Update countdown
        countdown--;
        countdownEl.textContent = countdown > 0 ? countdown : '';
        
        // Capture frame
        ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
        const frameData = canvas.toDataURL('image/jpeg');
        recordingFrames.push(frameData);
        
        // Stop after 3 seconds
        if (countdown <= 0) {
            clearInterval(state.recordingInterval);
            
            // Update state
            state[type].speechData = recordingFrames;
            state[type].speechRecorded = true;
            
            // Update UI
            speechIndicator.querySelector('.circle').classList.remove('recording');
            speechIndicator.querySelector('span').textContent = 'Recorded';
            recordBtn.disabled = false;
            updateSubmitButtonState(type);
            showMessage('Speech recorded!', type, 'success');
        }
    }, 100); // 10 frames per second
}

// Update submit button state
function updateSubmitButtonState(type) {
    const submitBtn = document.getElementById(`${type}-submit-btn`);
    submitBtn.disabled = !(state[type].faceCaptured && state[type].speechRecorded);
}

// Show message
function showMessage(message, type, status = '') {
    const messageEl = document.getElementById(`${type}-message`);
    messageEl.textContent = message;
    messageEl.className = 'message';
    if (status) {
        messageEl.classList.add(status);
    }
}

// Submit authentication
async function submitAuthentication(type) {
    const username = document.getElementById(`${type}-username`).value;
    
    if (!username) {
        showMessage('Please enter a username', type, 'error');
        return;
    }
    
    if (!state[type].faceCaptured) {
        showMessage('Please capture your face image', type, 'error');
        return;
    }
    
    if (!state[type].speechRecorded) {
        showMessage('Please record your speech', type, 'error');
        return;
    }
    
    // Show loading message
    showMessage(`Processing ${type === 'login' ? 'authentication' : 'registration'}...`, type);
    
    // Prepare data
    const data = {
        username,
        faceData: state[type].faceData,
        speechData: state[type].speechData
    };
    
    try {
        // Send request
        const response = await fetch(`/api/${type === 'login' ? 'authenticate' : 'register'}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showMessage(result.message, type, 'success');
            
            // Clear form for registration
            if (type === 'register') {
                document.getElementById(`${type}-username`).value = '';
                state[type].faceData = null;
                state[type].speechData = [];
                state[type].faceCaptured = false;
                state[type].speechRecorded = false;
                updateSubmitButtonState(type);
            }
        } else {
            showMessage(result.message, type, 'error');
        }
    } catch (error) {
        console.error(`Error during ${type}:`, error);
        showMessage(`Error during ${type}. Please try again.`, type, 'error');
    }
}

// Initialize application
async function init() {
    // Initialize login webcam
    const loginCamInitialized = await initWebcam(loginVideo);
    if (!loginCamInitialized) {
        showMessage('Error initializing webcam. Please allow camera access and refresh the page.', 'login', 'error');
    }
    
    // Set up login event listeners
    loginCaptureBtn.addEventListener('click', () => captureFace(loginVideo, loginCanvas, 'login'));
    loginRecordBtn.addEventListener('click', () => recordSpeech('login'));
    loginSubmitBtn.addEventListener('click', () => submitAuthentication('login'));
    
    // Initialize register webcam when switching to register tab
    registerTab.addEventListener('click', async () => {
        if (!registerVideo.srcObject) {
            const registerCamInitialized = await initWebcam(registerVideo);
            if (!registerCamInitialized) {
                showMessage('Error initializing webcam. Please allow camera access and refresh the page.', 'register', 'error');
            }
        }
    });
    
    // Set up register event listeners
    registerCaptureBtn.addEventListener('click', () => captureFace(registerVideo, registerCanvas, 'register'));
    registerRecordBtn.addEventListener('click', () => recordSpeech('register'));
    registerSubmitBtn.addEventListener('click', () => submitAuthentication('register'));
}

// Initialize on page load
window.addEventListener('load', init);